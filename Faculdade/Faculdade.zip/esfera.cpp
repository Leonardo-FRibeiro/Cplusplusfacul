#include "esfera.h"

double Esfera::CalculaRaio()
{
    
    return Raio;

   
}
 void Esfera::AtribuiRaio(double r){
        Raio = r;
}

double Esfera::CalculaVolume()
{

    return Volume;
}