#include <iostream> 
using namespace std;

class Esfera
{
    public:
    double CalculaRaio();
    double CalculaVolume();
    void AtribuiRaio( double r1);
   

    private:
    float PI = 3.1416;
    float Raio;
    float Volume;

};
